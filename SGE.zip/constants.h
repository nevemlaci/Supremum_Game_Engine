#pragma once

const int PLAYER_SPEED = 5;

const int SPRITE_SIZE = 32;